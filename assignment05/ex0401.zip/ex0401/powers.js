<!DOCTYPE html>
<html>
<body>

<script>
var s = "Numbers: ";
for(var i=5; i<=15 ;i++) {
s = s + i + " ";
}
s = s+"\nSquares: ";
for(var i=5; i<=15 ;i++) {
s = s + (i* i) + " ";
}
s = s+"\nCubes: ";
for(var i=5; i<=15 ;i++) {
s = s + (i* i*i) + " ";
}
alert(s);
</script>

</body>
</html>